﻿namespace CounterStrike.Utilities.Enumerations
{
    public enum Players
    {
        Terrorist = 1,
        CounterTerrorist = 2
    }
}