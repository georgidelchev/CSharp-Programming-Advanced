﻿using CounterStrike.Models.Guns.GunsModels;

namespace CounterStrike.Utilities.Enumerations
{
    public enum Guns
    {
        Pistol = 1,
        Rifle = 2
    }
}